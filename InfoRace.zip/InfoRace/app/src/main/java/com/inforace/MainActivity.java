package com.inforace;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Definir una constante para el ID del elemento del menú
    private static final int MENU_ITEM_FORMULA_1 = R.id.formula_1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Obtener referencia al botón fórmulas
        Button botonF = findViewById(R.id.boton_f);

        // Establecer listener para el botón de fórmulas
        botonF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Mostrar el menú popup
                showPopupMenu(v);
            }
        });

        // Obtener referencia al botón de coches deportivos
        Button botonSP = findViewById(R.id.boton_SP);

        // Establecer listener para el botón de coches deportivos
        botonSP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción cuando se hace clic en el botón de coches deportivos
                Toast.makeText(MainActivity.this, "Botón de coches deportivos pulsado", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.menu_f, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {
                // Manejar la acción del elemento de menú seleccionado
                if (item.getItemId() == MENU_ITEM_FORMULA_1) {
                    // Abrir la actividad F1Activity
                    Intent intent = new Intent(MainActivity.this, F1Activity.class);
                    startActivity(intent);
                    return true;
                } else {
                    return false;
                }
            }
        });
        popupMenu.show();
    }
}
