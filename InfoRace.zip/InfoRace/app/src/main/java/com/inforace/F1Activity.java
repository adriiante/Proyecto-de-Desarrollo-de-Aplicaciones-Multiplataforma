package com.inforace;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class F1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.f1_activity); // Aquí se establece el contenido del diseño de f1_activity.xml
    }
}
